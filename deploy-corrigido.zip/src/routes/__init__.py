# Initializes the routes package

