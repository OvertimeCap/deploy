from .user import User
from .cliente_potencial import ClientePotencial
from .cliente_finalizado import ClienteFinalizado
